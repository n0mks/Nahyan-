# قالب رسائل UiPath وOutlook — بنك عُمان العربي

قالب HTML واحد لإشعارات نجاح تنزيل التقارير وفشلها. التصميم بالإنجليزية، باستخدام درجات أزرق وأبيض ورمادي مستوحاة من شعار البنك المنشور. هذه الدرجات اقتراح تصميمي وليست أكواد الهوية الرسمية المعتمدة. تم حذف اسم البنك من رأس الرسالة وتحديث النص بعد Dear All بصياغة مهنية في حالتي النجاح والفشل. يعرض الرأس ROBO وUiPath automation، ويظل اسم التقرير متغيرًا في العنوان ونص الرسالة.

## الملفات

- `OAB_Email_Template.html`: القالب المشترك القابل لإعادة الاستخدام.
- `Success_Body.vb` و`Failure_Body.vb`: تعبيرات VB.NET لخاصية Body بعد قراءة القالب إلى متغير EmailTemplate.
- `Success_Direct_Body.vb` و`Failure_Direct_Body.vb`: بديل مباشر، يحتوي القالب داخل التعبير نفسه؛ يُلصق في Body دون Read Text File. استخدم طريقة واحدة فقط.
- `Preview_Success.html` و`Preview_Failure.html`: معاينة ثابتة في المتصفح؛ لا تستخدمهما للإرسال اليومي.
- ملفا PNG: معاينة مرئية للتصميم.

## الإعداد الموصى به لإعادة الاستخدام

1. انسخ `OAB_Email_Template.html` إلى `Data\EmailTemplates` داخل مشروع UiPath، وتأكد من وجود الملف مع ملفات المشروع المنشورة على جهاز الروبوت. يمكن أيضًا استعمال مسار كامل من Config.
2. أضف Read Text File واقرأ الملف بترميز UTF-8. احفظ النتيجة في متغير String اسمه `EmailTemplate`.
   مثال لمسار الملف إذا كان مجلد التشغيل هو جذر المشروع:

```vb
System.IO.Path.Combine(Environment.CurrentDirectory, "Data", "EmailTemplates", "OAB_Email_Template.html")
```

3. جهّز المتغيرات الموضحة أدناه.
4. في مسار النجاح، انسخ محتوى `Success_Body.vb` كاملًا إلى محرر التعبير الخاص بخاصية Body في Send Outlook Mail Message.
5. في Catch/مسار الفشل، انسخ محتوى `Failure_Body.vb` كاملًا إلى Body. يجب أن تكون Process_Stage وExc_Details في النطاق نفسه؛ إذا كان متغير Catch لديك اسمه exception، عيّن `Exc_Details = exception` أو استبدل الاسم في التعبير.
6. للإصدارات التي تعرض IsBodyHtml، اجعله True. في الواجهة الحديثة: القائمة + بجانب Body ثم Body as html. ضع التعبير في محرر التعبير؛ لا تلصق نص VB داخل محرر WYSIWYG.
7. الإرسال بهذا النشاط يعتمد على Outlook الكلاسيكي المثبت وملف تعريف البريد المهيأ على جهاز الروبوت. توافق نشاط الإرسال مختلف عن عرض الرسالة في تطبيقات المستلمين.

## المتغيرات

| الاسم | النوع | القيمة/الاستخدام |
|---|---|---|
| EmailTemplate | String | نتيجة Read Text File؛ لا يلزم عند استخدام ملفات Direct |
| ReportName | String | `"BIRT NOP"` |
| RunTimestamp | DateTime | وقت اكتمال الحفظ أو وقوع الفشل؛ التقطه مرة واحدة عند الحدث |
| OutputFolder1 | String | متغير مسار الحفظ الفعلي الأول؛ مطلوب للنجاح |
| OutputFolder2 | String | متغير مسار الحفظ الفعلي الثاني؛ مطلوب للنجاح |
| Process_Stage | String | المرحلة الحالية، من البروسس الموجود؛ مطلوب للفشل |
| Exc_Details | System.Exception | الاستثناء من Catch؛ مطلوب للفشل |

عيّن الوقت عند الحدث الفعلي:

```vb
DateTime.Now
```

هذا وقت جهاز الروبوت المحلي. إن كان الجهاز يستخدم منطقة زمنية مختلفة، استخدم وقت الحدث المحوّل إلى المنطقة الزمنية المطلوبة. لا يُنشئ القالب مسارات مجلدات ولا يعيد حسابها من التاريخ؛ يقرأ مسارات الحفظ الفعلية التي مررتها له.

قيم تجربة مطابقة للرسالة المطلوبة؛ لا تتركها ثابتة في التشغيل اليومي:

```vb
ReportName = "BIRT NOP"
RunTimestamp = New DateTime(2026, 9, 16, 8, 9, 0)
OutputFolder1 = "E:\UiPath\Daily\BIRT_NOP\Output2\2026\September\16\"
OutputFolder2 = "E:\UiPath\Daily\BIRT_NOP\Output\2026\September\16\"
```

الأسطر السابقة لتوضيح قيم Assign منفصلة؛ ليست تعبيرًا واحدًا يُلصق في Body.

## Subject

النجاح:

```vb
"[SUCCESS] " & ReportName & " | Report downloaded | " & RunTimestamp.ToString("dd MMM yyyy HH:mm", System.Globalization.CultureInfo.InvariantCulture)
```

الفشل:

```vb
"[FAILED] " & ReportName & " | Report download failed | " & RunTimestamp.ToString("dd MMM yyyy HH:mm", System.Globalization.CultureInfo.InvariantCulture)
```

## تعديل القالب

- عدّل الألوان والتنسيق في OAB_Email_Template.html مرة واحدة، وستستخدم رسائل النجاح والفشل التصميم نفسه.
- النصوص الإضافية الخاصة بكل حالة موجودة في ملف Body الموافق لها.
- إذا استعملت ملفات Direct، يجب تطبيق أي تغيير تصميمي على كلا التعبيرين لأن كل واحد يحتوي نسخة من HTML.
- متغيرات اسم التقرير والمسارات والمرحلة والخطأ تُرمّز بـ System.Net.WebUtility.HtmlEncode قبل إدخالها في HTML. لا تُزل هذه المعالجة؛ فهي تحافظ على عرض الرموز مثل < و& بشكل صحيح. تُحفظ فواصل الأسطر في رسالة الخطأ.
- يستخدم القالب جداول وCSS داخل العناصر، مع إطار عرض ثابت لـOutlook الكلاسيكي وإطار مرن للمتصفحات، ولا يعتمد على تحميل صور خارجية أو خطوط مخصصة أو JavaScript.
- مسارات E:\ نصوص قابلة للنسخ. تشير إلى جهاز/بيئة الروبوت؛ ليست روابط مشاركة عامة. لتوفير وصول للمستلمين، استخدم مسار شبكة متاحًا لهم أو رابط SharePoint فعليًا.
- لا يضيف القالب مرفقات ولا يثبت وجود الملفات. شغّل رسالة النجاح بعد التأكد من اكتمال الحفظ في كلا المجلدين.

## المعاينة والتحقق

معاينة النجاح تستخدم التاريخ والمسارين والوقت الواردة في الطلب. استثناء الفشل في المعاينة مثال توضيحي فقط. نسخة الفشل التشغيلية تستخدم الاستثناء الفعلي من Exc_Details.

أُنشئت المعاينات بواسطة محرك HTML مستقل، وليست لقطات من Outlook. لم يُنفّذ نشاط UiPath ولم تُرسل رسالة فعلية. قبل الاعتماد، جرّب الرسالة في Outlook المستخدم لديكم؛ قد تغيّر بعض الإصدارات أو الوضع الداكن تفاصيل الألوان والتباعد.

## مراجع الإعداد

- UiPath — Send Outlook Desktop Mail Message: https://docs.uipath.com/activities/other/latest/productivity/send-outlook-mail
- UiPath — New Outlook impact: https://docs.uipath.com/activities/other/latest/productivity/new-outlook-impacts-outlook-desktop-activities
- Microsoft — HTML formatting and the Word engine: https://learn.microsoft.com/en-us/troubleshoot/outlook/user-interface/formatting-lost-when-editing-the-htmlbody-property
- المرجع البصري للألوان: https://www.oman-arabbank.com/wp-content/uploads/SiteLogo-300x97.png
