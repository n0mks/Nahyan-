EmailTemplate.
Replace("{{REPORT_NAME}}", System.Net.WebUtility.HtmlEncode(ReportName)).
Replace("{{STATUS_BACKGROUND}}", "#EAF7F0").
Replace("{{STATUS_COLOR}}", "#176741").
Replace("{{STATUS_TEXT}}", "COMPLETED").
Replace("{{RESULT_TEXT}}", "Download completed successfully").
Replace("{{MESSAGE_HTML}}", "The <strong>" & System.Net.WebUtility.HtmlEncode(ReportName) & "</strong> report has been successfully downloaded and saved to the designated folders. The completion details and folder locations are provided below for your reference.").
Replace("{{RUN_DATE}}", RunTimestamp.ToString("dd MMM yyyy", System.Globalization.CultureInfo.InvariantCulture)).
Replace("{{RUN_TIME}}", RunTimestamp.ToString("HH:mm", System.Globalization.CultureInfo.InvariantCulture)).
Replace("{{DETAILS_HEADING}}", "SAVED LOCATIONS").
Replace("{{DETAILS_HTML}}", "<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='width:100%;table-layout:fixed;border-collapse:collapse;'><tr><td style='padding:13px 15px;background-color:#F8FAFC;border:1px solid #DCE5EE;font-family:Arial,Helvetica,sans-serif;'><p style='margin:0 0 6px;font-size:11px;line-height:16px;font-weight:bold;color:#52677C;'>Folder 01</p><p style='margin:0;font-family:Consolas,Courier New,monospace;font-size:12px;line-height:20px;color:#23374D;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-all;'>" &
    System.Net.WebUtility.HtmlEncode(OutputFolder1) &
    "</p></td></tr><tr><td height='10' style='height:10px;font-size:1px;line-height:10px;'>&nbsp;</td></tr><tr><td style='padding:13px 15px;background-color:#F8FAFC;border:1px solid #DCE5EE;font-family:Arial,Helvetica,sans-serif;'><p style='margin:0 0 6px;font-size:11px;line-height:16px;font-weight:bold;color:#52677C;'>Folder 02</p><p style='margin:0;font-family:Consolas,Courier New,monospace;font-size:12px;line-height:20px;color:#23374D;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-all;'>" &
    System.Net.WebUtility.HtmlEncode(OutputFolder2) &
    "</p></td></tr></table>")
