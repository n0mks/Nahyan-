("<!DOCTYPE html>" &
"<html lang=""en"" dir=""ltr"" xmlns:o=""urn:schemas-microsoft-com:office:office"">" &
"<head>" &
"  <meta charset=""utf-8"">" &
"  <meta name=""viewport"" content=""width=device-width, initial-scale=1"">" &
"  <meta name=""x-apple-disable-message-reformatting"">" &
"  <title>{{REPORT_NAME}} | Automation notification</title>" &
"  <!--[if mso]><noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript><![endif]-->" &
"</head>" &
"<body style=""margin:0;padding:0;background-color:#EDF2F7;color:#23374D;font-family:Arial,Helvetica,sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;"">" &
"  <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#EDF2F7"" style=""width:100%;background-color:#EDF2F7;border-collapse:collapse;mso-table-lspace:0pt;mso-table-rspace:0pt;"">" &
"    <tr><td align=""center"" style=""padding:28px 12px;"">" &
"      <!--[if mso]><table role=""presentation"" width=""640"" cellpadding=""0"" cellspacing=""0"" border=""0""><tr><td><![endif]-->" &
"      <div style=""width:100%;max-width:640px;margin:0 auto;"">" &
"      <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""width:100%;max-width:640px;border-collapse:collapse;mso-table-lspace:0pt;mso-table-rspace:0pt;"">" &
"        <tr><td height=""5"" bgcolor=""#0094D5"" style=""height:5px;font-size:1px;line-height:5px;background-color:#0094D5;"">&nbsp;</td></tr>" &
"        <tr><td bgcolor=""#003B70"" style=""padding:16px 28px;background-color:#003B70;"">" &
"          <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""width:100%;border-collapse:collapse;"">" &
"            <tr>" &
"              <td valign=""middle"" style=""font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:21px;font-weight:bold;letter-spacing:1px;color:#FFFFFF;"">ROBO</td>" &
"              <td align=""right"" valign=""middle"" style=""text-align:right;padding-left:12px;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:17px;color:#D6EAF7;"">UiPath automation</td>" &
"            </tr>" &
"          </table>" &
"        </td></tr>" &
"        <tr><td bgcolor=""#FFFFFF"" style=""padding:28px 28px 25px;background-color:#FFFFFF;border-left:1px solid #D9E3ED;border-right:1px solid #D9E3ED;"">" &
"          <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""border-collapse:collapse;"">" &
"            <tr><td bgcolor=""{{STATUS_BACKGROUND}}"" style=""padding:6px 10px;background-color:{{STATUS_BACKGROUND}};color:{{STATUS_COLOR}};border-left:3px solid {{STATUS_COLOR}};font-family:Arial,Helvetica,sans-serif;font-size:10px;line-height:14px;letter-spacing:1px;font-weight:bold;"">{{STATUS_TEXT}}</td></tr>" &
"          </table>" &
"          <h1 style=""margin:16px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:28px;line-height:35px;font-weight:bold;color:#003B70;"">{{REPORT_NAME}} report</h1>" &
"          <p style=""margin:5px 0 23px;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:20px;color:#52677C;"">{{RESULT_TEXT}}</p>" &
"          <p style=""margin:0 0 12px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:22px;color:#23374D;"">Dear All,</p>" &
"          <p style=""margin:0 0 22px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:23px;color:#23374D;"">{{MESSAGE_HTML}}</p>" &
"          <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" bgcolor=""#F1F6FA"" style=""width:100%;table-layout:fixed;background-color:#F1F6FA;border-collapse:collapse;"">" &
"            <tr>" &
"              <td valign=""top"" style=""padding:14px 16px;font-family:Arial,Helvetica,sans-serif;""><span style=""font-size:10px;line-height:15px;font-weight:bold;letter-spacing:1px;color:#52677C;"">DATE</span><br><span style=""font-size:14px;line-height:24px;font-weight:bold;color:#003B70;"">{{RUN_DATE}}</span></td>" &
"              <td valign=""top"" style=""padding:14px 16px;border-left:2px solid #FFFFFF;font-family:Arial,Helvetica,sans-serif;""><span style=""font-size:10px;line-height:15px;font-weight:bold;letter-spacing:1px;color:#52677C;"">TIME</span><br><span style=""font-size:14px;line-height:24px;font-weight:bold;color:#003B70;"">{{RUN_TIME}}</span></td>" &
"            </tr>" &
"          </table>" &
"          <p style=""margin:24px 0 12px;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:16px;font-weight:bold;letter-spacing:1px;color:#52677C;"">{{DETAILS_HEADING}}</p>" &
"          {{DETAILS_HTML}}" &
"          <p style=""margin:24px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:23px;color:#23374D;"">Regards,<br><strong style=""color:#003B70;"">ROBO</strong></p>" &
"        </td></tr>" &
"        <tr><td bgcolor=""#F8FAFC"" style=""padding:14px 28px;background-color:#F8FAFC;border:1px solid #D9E3ED;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:17px;color:#52677C;"">Automated notification &nbsp;&bull;&nbsp; UiPath</td></tr>" &
"      </table>" &
"      </div>" &
"      <!--[if mso]></td></tr></table><![endif]-->" &
"    </td></tr>" &
"  </table>" &
"</body>" &
"</html>").
Replace("{{REPORT_NAME}}", System.Net.WebUtility.HtmlEncode(ReportName)).
Replace("{{STATUS_BACKGROUND}}", "#FFF0F1").
Replace("{{STATUS_COLOR}}", "#A92436").
Replace("{{STATUS_TEXT}}", "ACTION REQUIRED").
Replace("{{RESULT_TEXT}}", "Report download failed").
Replace("{{MESSAGE_HTML}}", "The <strong>" & System.Net.WebUtility.HtmlEncode(ReportName) & "</strong> report could not be downloaded due to an error during processing. The affected stage and exception details are provided below for your review and corrective action.").
Replace("{{RUN_DATE}}", RunTimestamp.ToString("dd MMM yyyy", System.Globalization.CultureInfo.InvariantCulture)).
Replace("{{RUN_TIME}}", RunTimestamp.ToString("HH:mm", System.Globalization.CultureInfo.InvariantCulture)).
Replace("{{DETAILS_HEADING}}", "EXCEPTION DETAILS").
Replace("{{DETAILS_HTML}}", "<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='width:100%;table-layout:fixed;border-collapse:collapse;'><tr><td style='padding:13px 15px;background-color:#FFF8F8;border:1px solid #EED9DC;font-family:Arial,Helvetica,sans-serif;'><p style='margin:0 0 6px;font-size:11px;line-height:16px;font-weight:bold;color:#52677C;'>Failed stage</p><p style='margin:0;font-family:Consolas,Courier New,monospace;font-size:12px;line-height:20px;color:#23374D;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-all;'>" &
    System.Net.WebUtility.HtmlEncode(If(String.IsNullOrWhiteSpace(Process_Stage), "Not available", Process_Stage)) &
    "</p></td></tr><tr><td height='10' style='height:10px;font-size:1px;line-height:10px;'>&nbsp;</td></tr><tr><td style='padding:13px 15px;background-color:#FFF8F8;border:1px solid #EED9DC;font-family:Arial,Helvetica,sans-serif;'><p style='margin:0 0 6px;font-size:11px;line-height:16px;font-weight:bold;color:#52677C;'>Exception type</p><p style='margin:0;font-family:Consolas,Courier New,monospace;font-size:12px;line-height:20px;color:#23374D;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-all;'>" &
    System.Net.WebUtility.HtmlEncode(If(Exc_Details Is Nothing, "Not available", Exc_Details.GetType().FullName)) &
    "</p></td></tr><tr><td height='10' style='height:10px;font-size:1px;line-height:10px;'>&nbsp;</td></tr><tr><td style='padding:13px 15px;background-color:#FFF8F8;border:1px solid #EED9DC;font-family:Arial,Helvetica,sans-serif;'><p style='margin:0 0 6px;font-size:11px;line-height:16px;font-weight:bold;color:#52677C;'>Exception details</p><p style='margin:0;font-family:Consolas,Courier New,monospace;font-size:12px;line-height:20px;color:#23374D;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-all;'>" &
    System.Net.WebUtility.HtmlEncode(If(Exc_Details Is Nothing, "No exception details were provided.", If(Exc_Details.Message, "No exception message was provided."))).Replace(vbCrLf, vbLf).Replace(vbCr, vbLf).Replace(vbLf, "<br>") &
    "</p></td></tr></table>")
