# تجميع التقارير الشهرية في UiPath Windows-Legacy

الحل: Workflow واحد باسم `AggregateMonthlyReports.xaml` تستدعيه مرة واحدة من كل بروسس، بعد اكتمال التقرير القديم وحفظه وإغلاقه. يقرأ المجموعات من العمود `A` بدءًا من `A2` في `CRM Group.xlsx`، ثم ينشئ ملفًا لكل مجموعة أو يحدث الملف الموجود، ويضع شيت التقرير الحالي باسم `Report 1` أو `Report 2` أو `Report 3` أو `Report 4`.

**المرفق كود VB.NET لجسم `Invoke Code` ودليل لبناء Workflow داخل Studio؛ لا يتضمن XAML جاهزًا، ولم يُنفذ أو يُترجم داخل UiPath Studio أو Microsoft Excel هنا.** تمت مراجعة النص ومنطق التنفيذ. يلزم اختبار على نسخ من ملفاتك قبل اعتماد الإضافة في السيرفر.

## 1. النتيجة المتوقعة

إذا كانت أسماء القالب `SME`، `MME`، `Large Corp`، وغيرها، وكان تاريخ بيانات التقرير `2026-09-30` أو كانت فترة التقرير `2026-09`:

| Group في القالب | الملف النهائي | الشيتات بعد نجاح البروسسات الأربعة |
|---|---|---|
| `SME` | `Output\2026\Sep\New Report - SME.xlsx` | `Report 1`, `Report 2`, `Report 3`, `Report 4` |
| `MME` | `Output\2026\Sep\New Report - MME.xlsx` | `Report 1`, `Report 2`, `Report 3`, `Report 4` |
| `Large Corp` | `Output\2026\Sep\New Report - Large Corp.xlsx` | `Report 1`, `Report 2`, `Report 3`, `Report 4` |

وينطبق الأمر تلقائيًا على `Without RM`، `Branch`، `Liability`، `Retail SME`، `RMD`، وأي اسم جديد صالح في القالب. لا توجد قائمة مجموعات ثابتة في الكود. استخدم القالب ليحسم `SME` مقابل `SMR`؛ الكود لا يبدل الاسم ولا يصحح الهجاء تلقائيًا.

بعد البروسس الأول يحتوي كل ملف على `Report 1` فقط. البروسس الثاني يضيف `Report 2`، وهكذا. لا تُنشأ شيتات فارغة للتقارير التي لم تعمل بعد.

**وجود ملف المجموعة لا يعني تخطيه.** يعني تحميل شيتاته الحالية وإضافة/تحديث شيت البروسس الحالي. إعادة `Report 2` تستبدل `Report 2` فقط؛ لا تنشئ `Report 2 (2)` ولا تكرر الصفوف ولا تمسح باقي الشيتات.

## 2. الافتراضات والحدود

- المشروع `Windows-Legacy`، والتعبيرات في الأمثلة `VB.NET`، وMicrosoft Excel مثبت على حساب تشغيل الروبوت.
- الصورة الحالية تظهر `UiPath.Excel.Activities = 2.24.4` و`UiPath.System.Activities = 24.10.7`. الإضافة تحتاج نشاط `Invoke Code` الموجود ضمن `UiPath.System.Activities` ولا تحتاج حزمة Interop إضافية.
- كل بروسس ينتج ملف Excel نهائيًا واحدًا يحتوي بالفعل شيتات المجموعات المطلوبة. مصدر التصدير هو هذا الملف النهائي، وليس ملف التنزيل الخام ولا `CRM Group.xlsx`.
- أسماؤها تتطابق مع نصوص العمود `A` بعد حذف المسافات المحيطة. Excel وأسماء الملفات في Windows يعاملان اختلاف حالة الحروف دون إنشاء مجموعتين منفصلتين.
- المخرجات داخل المجلد الأساسي ثم مجلد السنة ثم مجلد الشهر الإنجليزي المختصر، مثل `Output\2026\Sep`. تستخدم جميع البروسسات نفس المجلد الأساسي ونفس فترة البيانات. فصل الشهر يمنع بقاء `Report 2` من شهر سابق إذا فشل تشغيل هذا التقرير في الشهر الجديد. يقبل `in_ReportPeriod` التاريخ الكامل بصيغة `yyyy-MM-dd` أو الشهر بصيغة `yyyy-MM`، ويستخرج الكود السنة والشهر لإنشاء المجلدات دون مجلد لليوم. يسجل الـJournal والـSummary الشهر الموحد في `Period` والقيمة الممررة في `InputPeriod`.
- `in_ReportPeriod` هو **تاريخ أو شهر البيانات**؛ لا تفترض أنه تاريخ التشغيل. لا يستطيع الكود التأكد من تاريخ البيانات داخل التقرير دون تحديد حقل/خلية يمثل الفترة. إذا كان المتغير القديم `previousDate` من نوع `String` وقيمته مثل `2026-09-30`، مرره كما هو. لا تغير متغير التاريخ المستخدم في اسم ملف المصدر.
- افتراضيًا `in_ValuesOnly = True`: يُنسخ الشيت كاملًا بتنسيقه، ثم تتحول صيغ الخلايا إلى نتائجها المحفوظة. إذا كنت تحتاج الصيغ استخدم `False`، واختبر المراجع إلى الشيتات الأخرى والملفات الخارجية؛ نقل شيت وحده لا ينقل كل الشيتات التي تعتمد عليها الصيغ.
- نسخ الشيت كاملًا يشمل الصفوف المخفية. إذا كان Excel يخفي بيانات المجموعات الأخرى باستخدام `AutoFilter` فقط، فذلك لا يكفي لإخراج بيانات المجموعة وحدها. يلزم تنظيف المصدر أو تصميم نسخ الصفوف المرئية وفق قاعدة العمل قبل استخدام هذا الحل.
- إذا كانت هناك صيغ مع AutoFilter يخفي صفوفًا فعليًا، يتوقف وضع `ValuesOnly=True` بدل تنفيذ لصق قد يعيد ترتيب البيانات المخفية. تجهيز بيانات المجموعة دون صفوف مخفية بالفلتر يحل هذه الحالة؛ مجرد ظهور أسهم الفلترة في العناوين لا يعني أن الفلتر فعال.
- هذا الحل مناسب لشيتات تقارير جاهزة. إذا كانت شيتاتك تعتمد على `PivotTables` أو `Power Query` أو وصلات بيانات أو حماية بكلمة مرور، يلزم فحص ملف فعلي قبل اعتماد النسخ؛ تحويل صيغ الخلايا إلى قيم لا يلغي وصلات تلك العناصر.
- المخرجات `.xlsx`؛ لا تنقل VBA إلى المخرجات. لا يحتاج الكود `Trust access to the VBA project object model`، ويعطل الماكرو أثناء فتح الملفات داخل Excel الذي ينشئه.
- لا تعدل المخرجات يدويًا أثناء تشغيل التجميع. القفل يمنع تعارض نسخ هذا الـWorkflow، ولا يمنع كل أدوات التحرير الخارجية. يتم أيضًا فحص تغير الملف قبل تحديثه، لكن الفحص والاستبدال ليسا قفلًا واحدًا ضد كل محرر خارجي.

## 3. مكان الإضافة في كل بروسس

1. احتفظ بمنطق التنزيل والفلترة والتنسيق القديم.
2. انتظر اكتمال `Save Workbook` أو `Save As` للملف النهائي الذي يحتوي شيتات المجموعات.
3. أغلق هذا الملف واخرج من `Excel Application Scope` الذي يديره. إذا كانت لديك مراجع Workbook محفوظة في المتغيرات فتأكد من إغلاق الملف فعليًا.
4. أضف `Invoke Workflow File` لاستدعاء `AggregateMonthlyReports.xaml` خارج الـExcel Scope.
5. ضع الاستدعاء قبل حذف ملف المصدر أو تنظيفه، وقبل إعلان نجاح البروسس.
6. نفذه **مرة واحدة لكل تقرير كامل**، لا داخل Loop صفوف البيانات ولا داخل Loop المجموعات القديمة؛ الكود ينفذ Loop المجموعات بنفسه.

لا تغير اسم متغير المسار القديم. اربطه مباشرة بالـArgument `in_SourceWorkbookPath` في الاستدعاء. لا نعرف اسمه الحقيقي من صورة Dependencies؛ `oldFinalReportPath` المذكور أدناه اسم توضيحي فقط.

إذا كنت تحتفظ بالـWorkbook من الـScope، يمكن استخدام نشاط `Close Workbook` من `UiPath.Excel.Activities` بعد آخر استخدام: `Workbook =` متغير الـ`WorkbookApplication` الموجود عندك. هذا الحقل لا يأخذ مسار `String`. وإذا كان `CRM Group.xlsx` مفتوحًا من جزء سابق، فأغلق مرجعه أيضًا قبل التصدير. لا تضف Close Workbook على ملف ما زالت خطوات لاحقة تحتاج استخدامه؛ ضع التصدير بعد انتهاء تلك الخطوات.

## 4. بناء AggregateMonthlyReports.xaml

أنشئ `Sequence` باسم `AggregateMonthlyReports.xaml` في المشروع الأول. بعد اختبارها انسخ نفس Workflow إلى المشاريع الثلاثة الأخرى. إذا كنت تدير UiPath Library مشتركة بالفعل، يمكن نشرها لاحقًا كجزء مشترك؛ لا يلزم إنشاء REFramework أو Queues لهذه الإضافة وحدها.

أضف في `Imports` إذا لم تكن متاحة: `System`, `System.IO`, `System.Collections.Generic`, `Microsoft.VisualBasic`, `System.Security.Cryptography`, `System.Runtime.InteropServices`, `System.Reflection`, `System.Text`, `System.Text.RegularExpressions`, `System.Globalization`, `System.Threading`, `UiPath.Core`.

الكود يستخدم أسماء أنواع مؤهلة بالكامل. لا تضف `Imports` أو `Option Strict` أو `Sub` أو `Module` حول الكود داخل `Invoke Code`.

### Workflow Arguments

| Name | Direction | Type | Scope | Default / الملاحظة |
|---|---|---|---|---|
| `in_SourceWorkbookPath` | `In` | `String` | Workflow كله | دون Default؛ مسار التقرير النهائي الخاص بالبروسس الحالي |
| `in_CrmGroupFilePath` | `In` | `String` | Workflow كله | دون Default؛ المسار الكامل إلى `CRM Group.xlsx` |
| `in_CrmGroupSheetName` | `In` | `String` | Workflow كله | `String.Empty` يختار أول Worksheet؛ الأفضل تمرير اسمه صراحة |
| `in_OutputRootFolder` | `In` | `String` | Workflow كله | دون Default؛ نفس المجلد الأساسي في الأربعة |
| `in_ReportNumber` | `In` | `Int32` | Workflow كله | دون Default؛ مرر `1` أو `2` أو `3` أو `4` صراحة |
| `in_ReportPeriod` | `In` | `String` | Workflow كله | دون Default؛ تاريخ البيانات مثل `"2026-09-30"` أو الشهر مثل `"2026-09"` |
| `in_ValuesOnly` | `In` | `Boolean` | Workflow كله | `True`؛ تحويل صيغ الخلايا إلى نتائجها مع حفظ التنسيق |
| `out_Summary` | `Out` | `String` | Workflow كله | `String.Empty` |
| `out_UpdatedFiles` | `Out` | `String[]` | Workflow كله | `New String() {}` |

في `Browse for Types` يمكن اختيار `Array of [T]` ثم `String` لنوع `String[]`. الكود يكتبه بصيغة VB.NET `String()`.

### Variables داخل Workflow

| Name | Type | Scope | Default |
|---|---|---|---|
| `rootException` | `System.Exception` | Sequence الرئيسية | `Nothing` |

متغير `exception` ينشأ من `Catch System.Exception` نفسه؛ لا تضف Variable ثانية تحمل الاسم نفسه.

### ترتيب Activities ومكان كل منها

| Step | Activity | Required package | Key properties and expressions | Expected result |
|---|---|---|---|---|
| 1 | `Try Catch` | Workflow Foundation مدمج | أضف `Sequence` في `Try` و`System.Exception` في `Catches`، وسم متغيره `exception` | تجميع أخطاء التصدير |
| 2 | `Log Message` داخل `Try` | `UiPath.System.Activities` | `Level = Info`; `Message = "[Aggregation] Started | Report=" & in_ReportNumber.ToString() & " | Period=" & in_ReportPeriod` | تسجيل البداية دون بيانات العملاء |
| 3 | `Invoke Code` داخل `Try` | `UiPath.System.Activities` | `Language = VBNet`; `Continue On Error = False`; `Private = True`؛ الصق محتوى `AggregateMonthlyReports_InvokeCode.txt` كاملًا في `Edit Code` | بناء وتحديث ملفات المجموعات |
| 4 | `Log Message` بعد `Invoke Code` داخل `Try` | `UiPath.System.Activities` | `Level = Info`; `Message = out_Summary` | تسجيل النجاح فقط عند اكتمال جميع الملفات |
| 5 | `Assign` داخل `Catch` | Workflow Foundation مدمج | `To = rootException`; `Value = exception` | حفظ الاستثناء |
| 6 | `While` داخل `Catch` | `UiPath.System.Activities` | `Condition = rootException.InnerException IsNot Nothing`؛ في `Body` ضع `Assign`: `rootException = rootException.InnerException` | كشف السبب الداخلي إذا لفه Invoke Code باستثناء آخر |
| 7 | `Log Message` داخل `Catch` | `UiPath.System.Activities` | `Level = Error`; التعبير التالي | تسجيل نوع السبب ورسالة الفشل |
| 8 | `If` داخل `Catch` | Workflow Foundation مدمج | `Condition = TypeOf rootException Is System.IO.InvalidDataException` | التمييز بين بيانات غير صالحة وأخطاء تشغيل |
| 9 | `Throw` داخل `Then` | Workflow Foundation مدمج | `Exception = New UiPath.Core.BusinessRuleException(rootException.Message)` | تصنيف غياب شيت مطلوب/قائمة مجموعات فارغة كخطأ عمل |
| 10 | `Rethrow` داخل `Else` | Workflow Foundation مدمج | دون تعبير | إعادة الخطأ الأصلي ومنع إعلان نجاح كاذب |

تعبير `Log Message` في خطوة 7:

```vb
"[Aggregation] Failed | Report=" & in_ReportNumber.ToString() &
" | Period=" & in_ReportPeriod &
" | Type=" & rootException.GetType().FullName &
" | Message=" & rootException.Message
```

لا يحتاج `Finally` الخارجي إلى `Kill Process`؛ كود `Invoke Code` يغلق موارده داخل `Finally` الخاص به. لا توقف كل عمليات `EXCEL` على السيرفر.

### Edit Arguments داخل Invoke Code

هذه قائمة منفصلة عن قائمة الـArguments في Workflow. أضفها يدويًا بنفس الأسماء التالية:

| Name داخل Invoke Code | Direction | Type | Value |
|---|---|---|---|
| `in_SourceWorkbookPath` | `In` | `String` | `in_SourceWorkbookPath` |
| `in_CrmGroupFilePath` | `In` | `String` | `in_CrmGroupFilePath` |
| `in_CrmGroupSheetName` | `In` | `String` | `in_CrmGroupSheetName` |
| `in_OutputRootFolder` | `In` | `String` | `in_OutputRootFolder` |
| `in_ReportNumber` | `In` | `Int32` | `in_ReportNumber` |
| `in_ReportPeriod` | `In` | `String` | `in_ReportPeriod` |
| `in_ValuesOnly` | `In` | `Boolean` | `in_ValuesOnly` |
| `out_Summary` | `Out` | `String` | `out_Summary` |
| `out_UpdatedFiles` | `Out` | `String[]` | `out_UpdatedFiles` |

لأن أسماء الـArguments والقيم متطابقة، لا تغير أسماء العناصر داخل الكود. قيمة `Out` يجب أن تكون Argument أو Variable قابلًا للكتابة، لا نصًا بين علامتي اقتباس.

## 5. الربط من كل بروسس قديم

أضف المتغيرات الجديدة في Scope الـSequence التي تستدعي Workflow، أو استخدم مفاتيح Config الموجودة عندك للمدخلات. المسارات التالية أمثلة ويجب استبدالها بمسارات السيرفر الفعلية؛ يفضل `UNC` مثل `\\server\share\...` في تشغيل السيرفر بدل mapped drive خاص بمستخدم.

| Variable مثال | Type | Default / مثال إعداد |
|---|---|---|
| `crmGroupPath` | `String` | `"D:\RPA\Config\CRM Group.xlsx"` |
| `crmGroupSheetName` | `String` | `String.Empty` لأول Worksheet، أو اسمه الحقيقي |
| `groupOutputRoot` | `String` | `"D:\RPA\Output\GroupedReports"` |
| `reportPeriod` | `String` | `"2026-09-30"` في الاختبار؛ في التشغيل من متغير تاريخ البيانات مثل `previousDate`، ويظل `"2026-09"` مقبولًا |
| `exportSummary` | `String` | `String.Empty` |
| `exportedFiles` | `String[]` | `New String() {}` |

إذا كان `previousDate` من نوع `String` بصيغة `yyyy-MM-dd`، اضبط `Assign` بقيمة `reportPeriod = previousDate`، أو اربط `in_ReportPeriod` بـ`previousDate` مباشرة في `Import Arguments`. وإذا كان عندك متغير `reportDate` من نوع `DateTime` يمثل تاريخ البيانات فعليًا، يمكن استخدام:

```vb
reportDate.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture)
```

لا تستخدم `DateTime.Now` ولا `AddMonths(-1)` إلا إذا كانت قاعدة العمل تنص على ذلك.

إعداد `Invoke Workflow File`:

- `WorkflowFileName = "AggregateMonthlyReports.xaml"`
- `Isolated = False`
- `Continue On Error = False`
- استخدم `Import Arguments` أو `Refresh Arguments` بحسب نسخة Studio.

| Workflow Argument | Value في البروسس القديم |
|---|---|
| `in_SourceWorkbookPath` | **المتغير القديم الذي يحتوي مسار التقرير النهائي**؛ مثل `oldFinalReportPath` إن كان هذا اسمه فعلًا |
| `in_CrmGroupFilePath` | `crmGroupPath` |
| `in_CrmGroupSheetName` | `crmGroupSheetName` |
| `in_OutputRootFolder` | `groupOutputRoot` |
| `in_ReportNumber` | ثابت خاص بالبروسس، وفق الجدول أدناه |
| `in_ReportPeriod` | `reportPeriod` |
| `in_ValuesOnly` | `True` للنتائج النهائية، أو `False` إذا كانت الصيغ مطلوبة |
| `out_Summary` | `exportSummary` |
| `out_UpdatedFiles` | `exportedFiles` |

| البروسس | Source workbook | in_ReportNumber | شيت الوجهة |
|---|---|---:|---|
| الأول | ملف التقرير النهائي الأول | `1` | `Report 1` |
| الثاني | ملف التقرير النهائي الثاني | `2` | `Report 2` |
| الثالث | ملف التقرير النهائي الثالث | `3` | `Report 3` |
| الرابع | ملف التقرير النهائي الرابع | `4` | `Report 4` |

كل مسارات المخرجات وشهر البيانات وملف CRM Group مشتركة بين الأربعة. الاختلاف هو مصدر البيانات ورقم التقرير فقط.

## 6. لماذا Invoke Code وليس Read/Write Text + Invoke VBA؟

الـ`.txt` في هذا المرفق مجرد ملف لتسليم **VB.NET** تنسخ محتواه إلى `Edit Code`. لا تمرره إلى `Invoke VBA` ولا تكتب الكود مرة ثانية بـ`Write Text File` أثناء التشغيل.

الطريقة القديمة `Read Text File → Replace → Write Text File → Invoke VBA` تستخدم **VBA** وتحقن أسماء الشيتات في نص الماكرو. هذه الإضافة تستخدم Arguments مباشرة، وتستخدم `CallByName` لاستدعاء Excel COM دون الاعتماد على Selectors أو نافذة نشطة. فتح المصدر والوجهة في نفس Excel Application مطلوب لنجاح `Worksheet.Copy`.

إذا ظهرت حاجة للالتزام بـVBA لأسباب بيئية فعلية، يمكن تحويل المنطق إلى ملف VBA ثابت بمعاملات؛ لا نحتاج بناء نسخة مختلفة من الكود لكل مجموعة. هذا بديل لاحق، وليس ملفًا إضافيًا مطلوبًا للحل الحالي.

## 7. الفحوصات والأخطاء والاستعادة

| الحالة | سلوك الكود | التصنيف/الإجراء |
|---|---|---|
| Input path أو الشهر أو Report number غير صالح | `ArgumentException`/`ArgumentOutOfRangeException` | خطأ إعدادات؛ إيقاف وتصحيح، دون Retry |
| ملف المصدر أو CRM Group غير موجود | `FileNotFoundException` | إيقاف التصدير والتأكد من نجاح الجزء القديم والمسار |
| ملف Input ما زال مفتوحًا أو Output مقفل | `IOException` | أغلق الملف/انتظر انتهاء التشغيل الآخر؛ لا تتجاوز الخطأ |
| المجلد غير موجود | `Directory.CreateDirectory` ينشئه | لا حاجة لخطوة Create Folder إضافية |
| المجلد غير متاح أو صلاحياته غير كافية | `IOException`/`UnauthorizedAccessException` | تصحيح صلاحيات حساب Robot/اتصال السيرفر |
| لا توجد أسماء من A2 أو يوجد اسم غير صالح | `InvalidDataException` ثم `BusinessRuleException` في الـCatch | تصحيح CRM Group؛ لا Retry تلقائي |
| اسم مجموعة مكرر | حذف التكرار من قائمة العمل مع تسجيل العدد | ملف واحد لكل اسم، مع تجاهل اختلاف حالة الحروف |
| المجموعة موجودة في CRM Group لكن شيتها مفقود من المصدر | فحص جميع المجموعات ثم `InvalidDataException` قبل نشر أي ملف | تصحيح الجزء القديم أو القالب وإعادة التصدير |
| الشيت موجود لكنه بدون معاملات | ينسخ الشيت كما هو، ولو كان Headers فقط | لا يستخدم `CopyToDataTable()`، فلا يظهر خطأ no DataRows بسبب الفراغ |
| ملف المجموعة غير موجود | ينشئ ملفًا بالشيت الحالي فقط | باقي الشيتات تأتي من تشغيل التقارير الأخرى |
| الملف موجود والشيت الحالي غير موجود | يحتفظ ببقية الشيتات ويضيف الحالي | لا إنشاء ملف نهائي إضافي |
| الشيت الحالي موجود | يستبدله بالمصدر الحالي ويحافظ على بقية الشيتات | تكرار التشغيل لا يكرر الصفوف/الشيتات |
| Excel يرفض COM call بسبب busy | بحد أقصى 3 محاولات إجمالية للنداء المعني فقط | لا إعادة للتصدير كله داخل الكود |
| ملف Output تغير أثناء تجهيز التصدير | يفشل فحص SHA256 قبل استبداله | راجع التحرير المتزامن ثم أعد التشغيل |
| تعطل التصدير أثناء تجهيز الملفات | لا ينشر الملفات التي لم يكمل تجهيزها | المخرجات الحالية محفوظة؛ تبقى `_work` للفحص |
| تعطل أثناء نشر أكثر من ملف | قد تكون بعض الملفات حدثت وبعضها لم يحدث؛ الـLog يوضح المجموعات المكتملة | أعد نفس التقرير للشهر نفسه؛ شيتاته تُستبدل بأمان دون تكرار |

المحاولات الثلاث في Excel تخص فقط أكواد COM التي تعني رفض الطلب قبل تنفيذه. لا يوجد Retry لتسجيل معاملات أو تنزيلات أو لتصدير كل البروسس. إذا أردت Retry إضافيًا على مستوى Workflow، فاجعله محدودًا لأخطاء التشغيل المؤقتة فقط، مع مراعاة Retry الموجود في REFramework/Orchestrator عندك. لا تضع عدة أنظمة Retry مستقلة حول البروسس كاملًا.

تحديث عدة ملفات ليس معاملة واحدة يمكن التراجع عنها تلقائيًا كلها. الكود يستخدم ملفات Staging أولًا، و`File.Replace` مع Backup للملفات الموجودة؛ إذا كان السيرفر/Share لا يدعم ذلك، يفشل بدل استخدام Delete ثم Copy قد يفقد الملف. اختبر هذه الخطوة على نفس مسار الإنتاج وحساب Robot.

## 8. الملفات المساعدة والتشغيل الشهري

- الملفات النهائية مباشرة داخل `<OutputRoot>\<yyyy>\<MMM>`، مثل `Output\2026\Sep`. تؤخذ السنة والشهر من فترة بيانات التقرير، وتكون أسماء الشهر بالإنجليزية باستخدام `InvariantCulture`. ينشئ الكود المجلدات غير الموجودة تلقائيًا.
- `_backup\<RunId>` يحتوي النسخة السابقة من كل ملف موجود تم استبداله في ذلك التشغيل.
- `_logs` يحتوي Journal لكل تشغيل؛ يشمل RunId والمجموعة وحالة Staged/Committed وعدد الملفات، دون نسخ بيانات الصفوف.
- `_work\<RunId>` للتجهيز. يزال مجلد التشغيل عند النجاح، ويبقى عند الفشل للفحص. لا تحذف ملفات عمل تشغيل حي.
- `.monthly-report-aggregation.lock` ملف قفل داخلي. وجود الملف وحده لا يعني أن هناك Job يعمل؛ القفل هو الـFileStream المفتوح، ويزول عند إغلاقه/خروج العملية. لا تحذف الملف يدويًا لحل تعارض تشغيلين.

لا توجد خطوة تلقائية لحذف مجموعات أزيلت من القالب. ملفاتها الموجودة تبقى لحفظ التقارير؛ إن كانت قاعدة العمل تتطلب إزالة هذه الملفات فذلك تغيير منفصل.

إذا أضيفت مجموعة بعد انتهاء Report 1 وReport 2، فلن توجد بيانات هذين التقريرين بمجرد تشغيل Report 3 وReport 4. أعد إنتاج/تصدير التقريرين السابقين لتلك الفترة بعد تحديث مصادرهما. الأفضل تثبيت قائمة مجموعات واحدة للدورة الشهرية وتشغيل الأربعة عليها.

## 9. الاختبار والقبول

ابدأ بملفي مجموعة في CRM Group تجريبي ومصادر التقارير الأربعة على نسخ، ومجلد Output تجريبي منفصل. شغل Validate في Studio ثم اختبر Report 1، ثم 2، ثم 3، ثم 4.

| Test | Sample input/action | Expected result |
|---|---|---|
| تشغيل الأربعة | CRM يحتوي `SME` و`MME`؛ مصدر لكل Report يحتوي الشيتين | ملفان، وفي كل منهما الشيتات الأربعة بالترتيب |
| تمييز المصدر | ضع علامة مختلفة في خلية اختبار بكل Report | كل تبويب يحتوي علامة مصدره الصحيح |
| إعادة Report 2 | غير قيمة في مصدره ثم أعده | تغير `Report 2` فقط؛ عدد شيتات التقارير يبقى 4 |
| مجموعة جديدة | أضف `New Group` إلى A4 وأضف شيتها لكل مصدر | ملف جديد بدون تعديل الكود |
| فراغات وتكرار | صف فارغ و` SME ` وصف `sme` | مجموعة SME واحدة، وتسجيل عدد التكرارات |
| قائمة فارغة | لا توجد أسماء من A2 | Business error؛ لا مخرجات جديدة |
| شيت مفقود | CRM يضم مجموعة لا توجد في مصدر أحد التقارير | Business error قبل نشر ملفات هذا التشغيل |
| شيت بيانات فارغ | Headers فقط | ملف/تبويب صحيح؛ لا خطأ no DataRows |
| ملف Input مفتوح | افتحه في Excel قبل التصدير | فشل واضح؛ أغلقه وأعد التجربة |
| ملف Output مفتوح | افتحه قبل Report 2 | لا فقد لـReport 1؛ يفشل التحديث حتى يغلق الملف |
| تزامن | شغل Exportين لنفس الشهر | أحدهما يفشل في القفل؛ لا كتابتان متعارضتان من نفس Workflow |
| الشهر الجديد | مرر فترة أخرى إلى Report 1 | مجلد شهر جديد؛ لا Report 2 قديم فيه |
| انقطاع بعد بعض Commits | أوقف Job في بيئة اختبار أثناء النشر ثم أعد نفس Report | اكتمال الملفات دون تكرار تبويبات |
| صيغة حسابية | Formula في المصدر؛ ValuesOnly=True | النتيجة في الوجهة قيمة مع نفس NumberFormat |
| تنسيق التامبلت | خلايا مدمجة، ألوان، عرض أعمدة، تواريخ، صفوف مخفية | فحص بصري/رقمي يطابق المصدر، مع تحويل الصيغ إن True |
| ملفات مقفلة/Share | اختبر على نفس UNC وحساب Robot | الحفظ وFile.Replace والنسخ الاحتياطي تعمل |

معايير القبول: عدد الملفات النهائية يساوي عدد أسماء المجموعات المميزة والصحيحة، وبعد نجاح الأربعة لكل ملف أربعة شيتات تقارير مرتبة، كل شيت يطابق بيانات مصدره وتنسيقه، إعادة التشغيل لا تضيف صفوفًا أو تبويبات مكررة، ولا تظهر رسالة نجاح بعد خطأ تصدير.

## 10. النشر والرجوع

1. خذ نسخة/إصدارًا معروفًا من المشاريع الحالية قبل الإضافة.
2. اختبر Workflow بالمشروع الأول ثم انقل النسخة نفسها إلى البقية، وعدل ربط المسار ورقم التقرير فقط.
3. حافظ على إصدارات Dependencies المتوافقة التي نجح عليها الاختبار. `UiPath.Excel.Activities 3.x` لا يدعم Windows-Legacy؛ لا ترق المشروع ضمن هذه الإضافة دون اختبار منفصل.
4. انشر المشاريع عبر آلية النشر الحالية. إن كان Orchestrator متاحًا، تحقق من حساب Robot والصلاحيات وConfig الفترة والمسارات وترتيب التشغيل 1→2→3→4.
5. لا تعتبر حزمة الشهر كاملة قبل نجاح الأربعة وفحص وجود شيتاتهم لكل مجموعة؛ لا تفترض أن نجاح Report 4 وحده يثبت نجاح البقية.
6. للرجوع: أوقف Jobs المتعلقة بالتجميع، ارجع لإصدار البروسس السابق، واستعد الملف المطلوب من `_backup` المناسب عند الحاجة بعد التحقق من الفترة والمجموعة. لا تستعد Backup أثناء عمل Export.

ملخص PDD: تصدير بيانات شيت كل مجموعة من أربعة تقارير شهرية إلى Workbook واحد للمجموعة، بتبويب لكل تقرير وبأسماء ديناميكية من CRM Group.

ملخص SDD: Sequence مشتركة، Arguments لمدخلات المصدر والتهيئة، Invoke Code يدير Excel COM مستقلًا، Validation قبل النشر، قفل تشغيل شهري، Staging وBackup وJournal، وإعادة تشغيل تستبدل شيت التقرير الحالي دون تكرار.

## 11. المراجع الرسمية

- [Invoke Code — UiPath](https://docs.uipath.com/activities/other/latest/workflow/invoke-code)
- [Excel Activities Release Notes — UiPath](https://docs.uipath.com/activities/other/latest/productivity/release-notes-uipath-excel-activities)
- [Worksheet.Copy — Microsoft](https://learn.microsoft.com/en-us/office/vba/api/excel.worksheet.copy)
- [Workbooks.Open — Microsoft](https://learn.microsoft.com/en-us/office/vba/api/excel.workbooks.open)
- [Close Workbook — UiPath](https://docs.uipath.com/activities/other/latest/productivity/excel-close-workbook)
- [Range.PasteSpecial — Microsoft](https://learn.microsoft.com/en-us/office/vba/api/excel.range.pastespecial)
- [Interaction.CallByName — Microsoft](https://learn.microsoft.com/en-us/dotnet/api/microsoft.visualbasic.interaction.callbyname)
- [File.Replace — Microsoft](https://learn.microsoft.com/en-us/dotnet/api/system.io.file.replace)
