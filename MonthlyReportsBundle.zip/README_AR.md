# خطوات تجميع التقارير — النسخة 2026-10-13-RangeExport3

## 1. نتيجة فحص الملفات المرفقة

- النسختان اللتان تنتهيان بـ(1) مطابقتان للنسختين الأوليين بالبايتات.
- المصدر ملف Excel 97–2003 حقيقي بصيغة BIFF8/OLE وامتداد .xls.
- ملف CRM بصيغة .xlsx، والشيت المطلوب CRM_Category، والأسماء في A2:A10.
- المجموعات التسع كلها موجودة في المصدر، وشيت Summary زائد عن قائمة CRM ولا يُصدَّر.
- المصدر المرفق لا يحتوي معاملات في شيتات المجموعات. الصفوف المتبقية بعد الصف الثاني فارغة ومنسقة.
- هناك 17 عنوان عمود أساسي في A:Q، و9 أعمدة إضافية منسقة فارغة حتى Z.
- صف العناوين، وهو الصف الثاني، فارغ بالكامل في Special Asset Management. الكود يستعيده من شيت سليم في نفس التقرير، وهو SME في هذه الملفات.
- Summary يحتوي 12 خلية خطأ بصيغ محفوظة. الكود لا يصدره ولا يغيره.

## 2. استبدال الكود في Workflow الحالي

1. افتح Framework\AggregateMonthlyReports.xaml.
2. افتح نشاط Invoke Code ثم Edit Code.
3. اضغط Ctrl+A واحذف النص القديم.
4. الصق محتوى AggregateMonthlyReports_InvokeCode.txt كاملًا.
5. Language = VBNet.
6. Continue On Error = False.
7. اترك نفس الـ9 Arguments الموجودة.
8. نفذ Validate File ثم Validate Project.
9. شغل Report 1 على مجلد Output تجريبي.
10. تأكد أن أول سطر باللوق يحتوي Build=2026-10-13-RangeExport3.

لا تضف Sub أو Class أو Module حول الكود. لا تستخدم Write Text File أو Invoke VBA لهذا النص.

## 3. Config

| المفتاح | القيمة |
|---|---|
| CRM_Group | المسار الكامل إلى ملف CRM Group.xlsx |
| CRM_Group_SheetName | CRM_Category |
| groupOutputRoot_Folder | مجلد المخرجات الأساسي المشترك بين البروسسات الأربعة |

ضع في groupOutputRoot_Folder مجلدًا أساسيًا مثل C:\RPA\GroupOutput. الكود ينشئ السنة والشهر، فلا تضفهما إلى هذا الإعداد.

## 4. Variables في البروسس المستدعي

| Name | Type | Assign |
|---|---|---|
| crmGroupPath | String | dtConfig("CRM_Group").ToString().Trim() |
| crmGroupSheetName | String | dtConfig("CRM_Group_SheetName").ToString().Trim() |
| groupOutputRoot | String | dtConfig("groupOutputRoot_Folder").ToString().Trim() |
| exportSummary | String | String.Empty |
| exportedFiles | String[] | New String() {} |

المتغير previousDate الموجود عندك يبقى كما هو. إذا كان String بقيمة 2026-09-30 مرره مباشرة.

## 5. Arguments داخل AggregateMonthlyReports.xaml وInvoke Code

| Name | Direction | Type |
|---|---|---|
| in_SourceWorkbookPath | In | String |
| in_CrmGroupFilePath | In | String |
| in_CrmGroupSheetName | In | String |
| in_OutputRootFolder | In | String |
| in_ReportNumber | In | Int32 |
| in_ReportPeriod | In | String |
| in_ValuesOnly | In | Boolean |
| out_Summary | Out | String |
| out_UpdatedFiles | Out | String[] |

في Edit Arguments لنشاط Invoke Code اربط كل اسم بنفس الاسم الموجود في Workflow.

## 6. ربط Invoke Workflow File في البروسس القديم

1. احفظ التقرير النهائي عبر نشاط الحفظ الموجود في البروسس القديم.
2. أغلق Workbook التقرير عبر Close Workbook إذا عندك متغير WorkbookApplication.
3. ضع Sequence التصدير خارج جميع Excel Application Scope التي تستخدم ملف التقرير.
4. أضف Sequence باسم AGG - Run Group Export.
5. أضف Assign للمتغيرات الخمسة في جدول القسم 4.
6. أضف Invoke Workflow File باسم AGG - Invoke Monthly Reports Export.
7. WorkflowFileName = "Framework\AggregateMonthlyReports.xaml".
8. Isolated = False.
9. Continue On Error = False.
10. افتح Import Arguments أو Refresh Arguments.
11. اربط القيم الآتية:

| Argument | Value |
|---|---|
| in_SourceWorkbookPath | تعبير أو متغير المسار النهائي الموجود عندك، والذي نجح في فتح CIB Book_work_w_2026-09-30.xls |
| in_CrmGroupFilePath | crmGroupPath |
| in_CrmGroupSheetName | crmGroupSheetName |
| in_OutputRootFolder | groupOutputRoot |
| in_ReportNumber | 1 في البروسس الأول؛ 2 أو 3 أو 4 في الباقي |
| in_ReportPeriod | previousDate |
| in_ValuesOnly | True |
| out_Summary | exportSummary |
| out_UpdatedFiles | exportedFiles |

إذا XMLpath عندك هو مجلد المصدر، يمكن استخدام التعبير:
System.IO.Path.Combine(XMLpath, "CIB Book_work_w_" & previousDate & ".xls")

لا تستخدم مسار CRM في in_SourceWorkbookPath. مصدر التصدير هو التقرير النهائي بعد الفلترة والحفظ.

## 7. الأنشطة داخل AggregateMonthlyReports.xaml

| الترتيب | Activity | DisplayName | الخصائص |
|---|---|---|---|
| 1 | Log Message | AGG - Start | Level = Info؛ Message = "[Aggregation] Started \| Report=" & in_ReportNumber.ToString() & " \| Period=" & in_ReportPeriod |
| 2 | Try Catch | AGG - Export Try Catch | جميع الأنشطة التالية داخلها |
| 3 | Invoke Code داخل Try | AGG - Export Group Cells | Language = VBNet؛ Continue On Error = False؛ Arguments مثل القسم 5؛ الصق الكود الكامل |
| 4 | Log Message بعد Invoke Code داخل Try | AGG - Success | Level = Info؛ Message = "[Aggregation] Completed \| " & out_Summary |
| 5 | Catch System.Exception | exception | أضف الأنشطة التالية داخله |
| 6 | Assign داخل Catch | AGG - Capture Root Exception | rootException = exception |
| 7 | While داخل Catch | AGG - Find Root Exception | Condition = rootException.InnerException IsNot Nothing |
| 8 | Assign داخل While | AGG - Unwrap Exception | rootException = rootException.InnerException |
| 9 | Log Message بعد While | AGG - Failure | Level = Error؛ Message = "[Aggregation] Failed \| Report=" & in_ReportNumber.ToString() & " \| Period=" & in_ReportPeriod & " \| Type=" & rootException.GetType().FullName & " \| Message=" & rootException.Message |
| 10 | If بعد Log | AGG - Classify Error | Condition = TypeOf rootException Is System.IO.InvalidDataException |
| 11 | Throw داخل Then | AGG - Throw Business Error | Exception = New UiPath.Core.BusinessRuleException(rootException.Message) |
| 12 | Rethrow داخل Else | AGG - Rethrow Technical Error | لا تضف Exception في Rethrow |

أضف Variable باسم rootException من نوع System.Exception، وScope يشمل Try Catch كله.

إذا هذا البناء موجود عندك بالفعل، استبدل نص Invoke Code فقط.

## 8. طريقة التصدير الجديدة

- لا يستخدم الكود Worksheet.Copy ولا ActiveWorkbook للتعرف على الشيت الناتج.
- ينشئ شيت الوجهة صراحةً، ويحصل على مرجعه من Worksheets.Add أو من أول شيت في Workbook الجديد.
- ينقل Range الخلايا إلى الوجهة المحددة، مع تنسيق الخلايا وعرض الأعمدة وارتفاع الصفوف وحالة إخفائها.
- إذا in_ValuesOnly = True، يكتب قيم المصدر المحفوظة مباشرة ويقارن كل قيمة في النطاق المنقول قبل الحفظ.
- يحتفظ بالأكواد النصية والأصفار في بدايتها. إذا حوّل Excel قيمة نصية إلى رقم، يعيدها كنص ويتحقق منها ويسجل TEXT_VALUES_PRESERVED.
- لا يضيف الأعمدة الثابتة إلى الكود. عدد الأعمدة ونطاق البيانات يُقرأ من كل شيت.
- يستبعد الصفوف المنسقة الفارغة بعد نهاية المحتوى؛ لا يحذف صفًا يحتوي قيمة صفر أو أي محتوى.
- إذا التقرير يستخدم صيغًا، احسبه واحفظه في البروسس القديم قبل الاستدعاء. التصدير يلتقط آخر القيم المحفوظة.
- هذا تصدير جدول وخلايا. لا ينقل مشروع VBA أو PivotTable أو اتصالات Power Query أو إعدادات الطباعة كميزات مستقلة.

## 9. الشيتات الناقصة والاختلافات

| الحالة | النتيجة |
|---|---|
| مجموعة جديدة أضيفت إلى CRM وشيتها موجود بالمصدر | يُنشأ ملف لها أو يُحدَّث الملف الموجود تلقائيًا |
| مجموعة موجودة في CRM وشيتها غير موجود بالمصدر | يُنشأ/يُستبدل شيت التقرير الحالي بعناوين فقط من شيت سليم في نفس التقرير |
| شيت مصدر ناقص | A1 يحتوي SOURCE SHEET MISSING مع اسم المجموعة؛ اللوق يحتوي MISSING_SOURCE_SHEET؛ Summary يحتوي MissingSheets |
| إعادة تقرير وكان شيت المجموعة ناقصًا هذه المرة | لا يترك بيانات التقرير القديم في الشيت الحالي؛ يستبدلها بالعناوين والتنبيه |
| شيت موجود وبلا بيانات | تُنسخ العناوين ويُسجل EMPTY_SOURCE_DATA |
| صف العناوين فارغ بالكامل | يُستعاد من شيت سليم في نفس التقرير ويُسجل HEADER_ROW_REPAIRED |
| بعض الأعمدة أقل أو أكثر | ينقل أعمدة هذا الشيت كما هي؛ لا يفرض قائمة أعمدة ثابتة |
| شيت زائد غير موجود في CRM مثل Summary | يتجاهله ويسجل IGNORED_SOURCE_SHEETS |
| اسم مجموعة مكرر في CRM | يعالج الاسم مرة واحدة |
| ملف المجموعة موجود | يحافظ على شيتات التقارير الأخرى ويحدّث الحالي |
| إعادة نفس رقم التقرير | يستبدل الشيت الحالي؛ لا يكرر الصفوف أو أسماء الشيتات |
| ملف Input مقفل | يفحص كل ثانيتين لمدة أقصاها 60 ثانية؛ إذا بقي مقفلًا، يُظهر تعليمات الحفظ والإغلاق |
| ملف Output مفتوح أو للقراءة فقط | يفشل قبل استبدال الملف النهائي |
| فلتر نشط ما زال يخفي بيانات المصدر | يتوقف بهذه المجموعة لتفادي تصدير بيانات غير مكتملة أو غير نهائية |
| لا يوجد أي شيت مطلوب بعناوين سليمة | يتوقف؛ لا يخترع أسماء الأعمدة |
| اختلاف نظام التواريخ بين المصدر والملف الموجود | يتوقف لتجنب تحريك التواريخ 4 سنوات |

الثوابت أعلى الكود:
- headerRow = 2 لأن ملفاتك تبدأ بعنوان في الصف الأول وأسماء الأعمدة في الصف الثاني.
- missingSheetPolicy = "HeadersOnly" هو السلوك المعتمد. يمكن تغييره إلى "Fail" لإيقاف التشغيل عند فقد أي شيت.
- repairEmptyHeaderRow = True لاستعادة صف العناوين الفارغ بالكامل. لا يكتب فوق صف عناوين موجود جزئيًا.

## 10. المجلدات واللوق

مع previousDate = "2026-09-30" أو "2026-09":
GroupOutput\2026\Sep\New Report - SME.xlsx

بعد نجاح التقارير الأربعة يحتوي الملف:
Report 1, Report 2, Report 3, Report 4

داخل مجلد الشهر:
- _logs: اللوق لكل تشغيل.
- _work: ملفات العمل المرحلية. تُحذف ملفات التشغيل الناجح، وتبقى ملفات التشغيل الفاشل للفحص.
- _backup: النسخ السابقة من الملفات التي تم تحديثها.
- .monthly-report-aggregation.lock: ملف القفل. وجوده وحده لا يعني أن التشغيل ما زال يعمل.

أسطر اللوق:
START، VALIDATED، IGNORED_SOURCE_SHEETS، MISSING_SOURCE_SHEET، TRANSFER_BEGIN، TEXT_VALUES_PRESERVED، HEADER_ROW_REPAIRED، EMPTY_SOURCE_DATA، TRANSFER_VERIFIED، STAGED، COMMITTED، SUCCESS، FAILED.

TRANSFER_VERIFIED يعني أن شيت الوجهة موجود في الملف الصحيح، وأن قيمه طابقت المصدر عند ValuesOnly=True، وأن الشيتات الأخرى محفوظة قبل الحفظ.
CommittedFiles=0 في FAILED يعني لم يُنشر أي ملف نهائي في هذا التشغيل.

## 11. الملفات التجريبية

- CIB_Report1_Sample.xlsx: نفس أسماء شيتات المصدر، 17 عمودًا أساسيًا، وصفّان ببيانات اختبار في معظم المجموعات. Branch وRetail SME بالعناوين فقط.
- CIB_Report1_Sample.xls: نفس المثال بعد تحويله إلى Excel 97–2003، لاختبار امتداد المصدر الحالي.
- CRM_Group_Sample.xlsx: نفس أسماء القروبات في CRM_Category وبيانات مسؤولين وهمية.
- New_Report_SME_Example.xlsx: شكل الناتج المتوقع بعد التقارير الأربعة، ببيانات مثال. لم ينتج من تشغيل UiPath هنا.

جميع العملاء والمسؤولين في الأمثلة بيانات اختبار. الملفات الأصلية المرفقة لم تُعدل.

اختبر بالترتيب:
1. استخدم ملف المثال .xls وCRM_Group_Sample.xlsx ومجلد Output جديد.
2. شغل Report 1 ثم Report 2.
3. أعد Report 1 وتأكد أن الملف يحتوي Report 1 وReport 2 فقط.
4. احذف شيت MME من نسخة المصدر التجريبية، وأعد Report 1. يجب أن MME يحتوي العناوين والتنبيه دون بيانات Report 1 السابقة.
5. أضف Test Group إلى A11 في CRM_Category. أعد Report 1. يجب إنشاء New Report - Test Group.xlsx بعناوين وتنبيه.
6. أضف شيت Test Group إلى نسخة المصدر وبيانات اختبار ثم أعد التصدير. يجب أن تتحول النتيجة إلى البيانات الجديدة بدل التنبيه.
7. شغل Report 3 ثم Report 4 وتأكد من ترتيب الشيتات.

## 12. التحقق وحدوده

فُحصت بنية الملفين الفعليين ونوعهما وأسماء الشيتات والعناوين وحالة فراغ البيانات وأخطاء الصيغ. فُحصت الملفات التجريبية والقيم والتواريخ والحزمة. لا يتوفر Microsoft Excel COM أو UiPath Studio في بيئة التنفيذ هنا؛ لا يُعد ذلك اختبار تشغيل للكود على روبوت Windows. التشغيل النهائي في UiPath مطلوب للتحقق من Excel COM وصلاحيات المسار الفعلي.

## 13. المراجع

- https://learn.microsoft.com/en-us/office/vba/api/excel.range.copy
- https://learn.microsoft.com/en-us/office/vba/api/excel.range.value2
- https://learn.microsoft.com/en-us/office/vba/api/excel.worksheets.add
- https://learn.microsoft.com/en-us/office/vba/api/excel.range.columnwidth
- https://learn.microsoft.com/en-us/office/vba/api/excel.range.rowheight
- https://docs.uipath.com/activities/other/latest/workflow/invoke-code
