EmailTemplate.
Replace("{{REPORT_NAME}}", System.Net.WebUtility.HtmlEncode(ReportName)).
Replace("{{STATUS_BACKGROUND}}", "#FFF0F1").
Replace("{{STATUS_COLOR}}", "#A92436").
Replace("{{STATUS_TEXT}}", "ACTION REQUIRED").
Replace("{{RESULT_TEXT}}", "Report download failed").
Replace("{{MESSAGE_HTML}}", "The <strong>" & System.Net.WebUtility.HtmlEncode(ReportName) & "</strong> report could not be downloaded due to an error during processing. The affected stage and exception details are provided below for your review and corrective action.").
Replace("{{RUN_DATE}}", RunTimestamp.ToString("dd MMM yyyy", System.Globalization.CultureInfo.InvariantCulture)).
Replace("{{RUN_TIME}}", RunTimestamp.ToString("HH:mm", System.Globalization.CultureInfo.InvariantCulture)).
Replace("{{DETAILS_HEADING}}", "EXCEPTION DETAILS").
Replace("{{DETAILS_HTML}}", "<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='width:100%;table-layout:fixed;border-collapse:collapse;'><tr><td style='padding:13px 15px;background-color:#FFF8F8;border:1px solid #EED9DC;font-family:Arial,Helvetica,sans-serif;'><p style='margin:0 0 6px;font-size:11px;line-height:16px;font-weight:bold;color:#52677C;'>Failed stage</p><p style='margin:0;font-family:Consolas,Courier New,monospace;font-size:12px;line-height:20px;color:#23374D;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-all;'>" &
    System.Net.WebUtility.HtmlEncode(If(String.IsNullOrWhiteSpace(Process_Stage), "Not available", Process_Stage)) &
    "</p></td></tr><tr><td height='10' style='height:10px;font-size:1px;line-height:10px;'>&nbsp;</td></tr><tr><td style='padding:13px 15px;background-color:#FFF8F8;border:1px solid #EED9DC;font-family:Arial,Helvetica,sans-serif;'><p style='margin:0 0 6px;font-size:11px;line-height:16px;font-weight:bold;color:#52677C;'>Exception type</p><p style='margin:0;font-family:Consolas,Courier New,monospace;font-size:12px;line-height:20px;color:#23374D;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-all;'>" &
    System.Net.WebUtility.HtmlEncode(If(Exc_Details Is Nothing, "Not available", Exc_Details.GetType().FullName)) &
    "</p></td></tr><tr><td height='10' style='height:10px;font-size:1px;line-height:10px;'>&nbsp;</td></tr><tr><td style='padding:13px 15px;background-color:#FFF8F8;border:1px solid #EED9DC;font-family:Arial,Helvetica,sans-serif;'><p style='margin:0 0 6px;font-size:11px;line-height:16px;font-weight:bold;color:#52677C;'>Exception details</p><p style='margin:0;font-family:Consolas,Courier New,monospace;font-size:12px;line-height:20px;color:#23374D;overflow-wrap:anywhere;word-wrap:break-word;word-break:break-all;'>" &
    System.Net.WebUtility.HtmlEncode(If(Exc_Details Is Nothing, "No exception details were provided.", If(Exc_Details.Message, "No exception message was provided."))).Replace(vbCrLf, vbLf).Replace(vbCr, vbLf).Replace(vbLf, "<br>") &
    "</p></td></tr></table>")
